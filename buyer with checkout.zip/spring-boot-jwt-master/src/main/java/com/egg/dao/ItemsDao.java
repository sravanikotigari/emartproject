package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.CartItems;


@Repository
public interface ItemsDao extends JpaRepository<CartItems, Integer> {
	
	@Query(value = "delete from cartitems where cartItemId=?1 and c.buyer_details_id_buyerid=?2",nativeQuery = true)
	  public void deleteByIds(@Param("id")int id, @Param("bid")int bid);
	 @Query(value = "select * from cartitems  where cartitems.buyerDetailsId_buyerID=:ids",nativeQuery = true)
	  public List<CartItems> getByBuyerId(@Param("ids")int ids);
	  

}
