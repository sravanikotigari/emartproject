package com.egg.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.egg.model.ApiResponse;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/hello")
public class HelloController {

   

    

    @GetMapping
    public String sayHello(){
        return "THIS IS PAVAN KLAYAN";

}
}